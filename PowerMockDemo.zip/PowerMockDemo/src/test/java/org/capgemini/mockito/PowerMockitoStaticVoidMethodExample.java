package org.capgemini.mockito;

import org.capgemini.mockito.Service;
import org.capgemini.mockito.ServiceListener;
import org.capgemini.mockito.SomeSystem;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;


@RunWith(PowerMockRunner.class)
public class PowerMockitoStaticVoidMethodExample {
	private Service service;
	private SomeSystem system;
	private ServiceListener serviceListener;

	@Before
	public void setupMock() {
		service = Mockito.mock(Service.class);
		serviceListener = Mockito.mock(ServiceListener.class);

		system = new SomeSystem();
		system.add(service);
		system.setServiceListener(serviceListener);
	}

	@PrepareForTest({ SomeSystem.class })
	@Test
	public void stubStaticVoidMethod() {		
		PowerMockito.mockStatic(SomeSystem.class);
		
		PowerMockito.doNothing().when(SomeSystem.class);
		SomeSystem.notifyServiceListener(serviceListener, service, true);
		
		PowerMockito.when(service.start()).thenReturn(1);		

	
		system.start();

		PowerMockito.verifyStatic();
		SomeSystem.startServiceStaticWay(service);

		Mockito.verify(serviceListener, Mockito.never()).onSuccess(service);
	}

	
}