package org.capgemini.mockito;

import org.capgemini.mockito.Service;
import org.capgemini.mockito.ServiceListener;
import org.capgemini.mockito.SomeSystem;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.modules.junit4.PowerMockRunner;


@RunWith(PowerMockRunner.class)
public class PowerMockitoStaticMethodExample {
	private Service service;
	private SomeSystem system;
	private ServiceListener serviceListener;

	@Before
	public void setupMock() {
		// Mock
		service = Mockito.mock(Service.class);
		serviceListener = Mockito.mock(ServiceListener.class);

		system = new SomeSystem();
		system.add(service);
		system.setServiceListener(serviceListener);
	}

	@Test
	public void stubStaticNonVoidMethod() {
		// Stub static method startServiceStatic to start successfully
	
		PowerMockito.mockStatic(SomeSystem.class);
		
		
		PowerMockito.when(SomeSystem.startServiceStaticWay(service))
				.thenReturn(1);

		// Run
	
		system.start();

		// Verify success
	
		Mockito.verify(serviceListener).onSuccess(service);

		// Stub static method startServiceStatic to fail
		
		PowerMockito.when(SomeSystem.startServiceStaticWay(service))
				.thenReturn(0);

		// Run
	
		system.start();

		// Verify failure
		
		Mockito.verify(serviceListener).onFailure(service);
	}

	
}