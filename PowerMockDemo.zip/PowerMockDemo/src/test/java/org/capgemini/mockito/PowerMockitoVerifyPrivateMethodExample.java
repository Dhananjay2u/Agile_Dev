package org.capgemini.mockito;


import org.capgemini.mockito.Service;
import org.capgemini.mockito.ServiceListener;
import org.capgemini.mockito.SomeSystem;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
public class PowerMockitoVerifyPrivateMethodExample {
	private Service service;
	private SomeSystem system;
	private ServiceListener serviceListener;

	@Before
	public void setupMock() {
		// Mock
		service = Mockito.mock(Service.class);
		serviceListener = Mockito.mock(ServiceListener.class);

		system = Mockito.spy(new SomeSystem());
		system.add(service);
		system.setServiceListener(serviceListener);
	}

	@Test
	public void verifyPrivateMethods() throws Exception {
		PowerMockito.when(service.start()).thenReturn(1);
		
		
		Mockito.when(service.getName()).thenReturn("serviceA");

		
		system.start();

		
		PowerMockito.verifyPrivate(system).invoke("addEvent",
				new Object[] { service, true });
		
	}
	
	
}