package org.capgemini.mockito;


import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.capgemini.mockito.Service;
import org.capgemini.mockito.ServiceListener;
import org.capgemini.mockito.SomeSystem;
import org.junit.Assert;


@PrepareForTest({ SomeSystem.class })
@RunWith(PowerMockRunner.class)
public class PowerMockitoStubPrivateMethodExample {
	private Service service;
	private SomeSystem system;
	private ServiceListener serviceListener;

	@Before
	public void setupMock() {
		// Mock
		service = Mockito.mock(Service.class);
		serviceListener = Mockito.mock(ServiceListener.class);

		system = PowerMockito.spy(new SomeSystem());
		system.add(service);
		system.setServiceListener(serviceListener);
	}

	@Test
	public void stubPrivateMethodAddEvent() throws Exception {
		PowerMockito.when(service.start()).thenReturn(1);
		
		Mockito.when(service.getName()).thenReturn("serviceA");
		
		PowerMockito.doNothing().when(system, "addEvent", service, true);

		system.start();

		Assert.assertTrue(system.getEvents().isEmpty());
	}
	
	@Test
	public void stubPrivateMethodGetEventString() throws Exception {
		final String serviceA = "serviceA";
		final String serviceA_is_successful = serviceA + " is successful";
		PowerMockito.when(service.start()).thenReturn(1);
		
		Mockito.when(service.getName()).thenReturn(serviceA);
		
		PowerMockito.when(system, "getEvent", serviceA, true).thenReturn(serviceA_is_successful);

		system.start();

		Assert.assertTrue(!system.getEvents().isEmpty());
		Assert.assertEquals(serviceA_is_successful, system.getEvents().get(0));
		System.out.println(system.getEvents());
	}

	
}