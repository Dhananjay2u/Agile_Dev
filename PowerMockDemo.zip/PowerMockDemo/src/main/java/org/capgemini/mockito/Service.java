package org.capgemini.mockito;

public interface Service {	
	String getName();
	int start();
}
