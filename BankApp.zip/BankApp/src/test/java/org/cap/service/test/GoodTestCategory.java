package org.cap.service.test;

public interface GoodTestCategory {

}
