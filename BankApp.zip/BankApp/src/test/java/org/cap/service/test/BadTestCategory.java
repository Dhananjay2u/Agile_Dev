package org.cap.service.test;

public interface BadTestCategory {

}
