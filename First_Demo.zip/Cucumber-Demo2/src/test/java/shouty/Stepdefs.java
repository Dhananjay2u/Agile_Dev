package shouty;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdefs {
	@Given("^Lucy is (\\d+) metres from Sean$")
	public void lucy_is_metres_from_Sean(int distance) throws Throwable {
	    System.out.println("Distance : " + distance);
	}

	@When("^Sean shouts \"(.*?)\"$")
	public void sean_shouts(String arg1) throws Throwable {
	    
	}

	@Then("^Lucy hears Sean's message$")
	public void lucy_hears_Sean_s_message() throws Throwable {
	   
	}

}
